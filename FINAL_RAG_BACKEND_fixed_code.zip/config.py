import os
from pathlib import Path

BASE_DIR=Path(__file__).resolve().parent
URL_DIR=BASE_DIR/"urls"
CACHE_DIR=BASE_DIR/"cache"
CLEANED_HTML_DIR=BASE_DIR/"cleaned_html"


TOP_K=4
CHUNK_SIZE=500
OVERLAP=100
CONTEXT_PAD=50            # extra characters of context stored on each side of a chunk

# batching
TEXT_EMBED_BATCH_SIZE=32  # chunks per embedding forward pass
UPSERT_BATCH_SIZE=256     # points per Qdrant upsert request
PDF_RENDER_SCALE=2        # pdfium render scale for page images (2 = 144 dpi)


#qdrant store location directory in memory
QDRANT_PATH=BASE_DIR/"qdrant_storage"
TEXT_COLLECTION_NAME="qwen_text_emb"
VISUAL_COLLECTION_NAME="vis_embed"

# Qwen3-Embedding-8B outputs 4096 dims and supports MRL truncation (32-4096).
TEXT_EMBED_DIM=2048
# colqwen3.5-4.5B-v3 has a 320-dim projection head (config.json: "dim": 320), NOT 128.
VISUAL_EMBED_DIM=320

TEXT_EMBED_MODEL="Qwen/Qwen3-Embedding-8B"
VISUAL_EMBED_MODEL="athrael-soju/colqwen3.5-4.5B-v3"
BASE_MODEL="Qwen/Qwen3-VL-8B-Instruct"
