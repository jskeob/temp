import threading
import torch
from qdrant_client import QdrantClient
from sentence_transformers import SentenceTransformer
from colpali_engine.models import ColQwen3_5, ColQwen3_5Processor
from transformers import Qwen3VLForConditionalGeneration, AutoProcessor
import config

# Serialises GPU-heavy work (embedding + generation) across request threads so that
# concurrent requests cannot run out of VRAM. RLock: the same thread may re-enter.
GPU_LOCK = threading.RLock()

# Guards lazy initialisation so two threads never load the same model twice.
_init_lock = threading.Lock()


class ClientManager:
    _qdrant = None
    @classmethod
    def get_qdrant(cls):
        if cls._qdrant is None:
            with _init_lock:
                if cls._qdrant is None:
                    cls._qdrant=QdrantClient(path=str(config.QDRANT_PATH))
        return cls._qdrant


class ModelRegistry:
    _text_embed = None
    _visual_embed= None
    _visual_processor = None
    _base_model = None
    _base_processor = None

    @classmethod
    def get_text_embed(cls):
        if cls._text_embed is None:
            with _init_lock:
                if cls._text_embed is None:
                    # Without an explicit dtype the 8B embedder may load in fp32 (~32 GB).
                    cls._text_embed = SentenceTransformer(
                        config.TEXT_EMBED_MODEL,
                        model_kwargs={"dtype": torch.bfloat16},
                    )
        return cls._text_embed

    @classmethod
    def get_visual_embed(cls):
        if cls._visual_embed is None:
            with _init_lock:
                if cls._visual_embed is None:
                    model = ColQwen3_5.from_pretrained(
                        config.VISUAL_EMBED_MODEL, dtype=torch.bfloat16,
                        attn_implementation="sdpa", device_map="auto"
                    ).eval()
                    if model.dim != config.VISUAL_EMBED_DIM:
                        raise RuntimeError(
                            f"{config.VISUAL_EMBED_MODEL} outputs {model.dim}-dim vectors but "
                            f"config.VISUAL_EMBED_DIM is {config.VISUAL_EMBED_DIM}.")
                    cls._visual_processor = ColQwen3_5Processor.from_pretrained(config.VISUAL_EMBED_MODEL)
                    cls._visual_embed = model
        return cls._visual_embed, cls._visual_processor

    @classmethod
    def get_base_model(cls):
        if cls._base_model is None:
            with _init_lock:
                if cls._base_model is None:
                    model = Qwen3VLForConditionalGeneration.from_pretrained(
                        config.BASE_MODEL,
                        dtype=torch.bfloat16,
                        attn_implementation="sdpa",
                        device_map="auto"
                    ).eval()
                    cls._base_processor = AutoProcessor.from_pretrained(config.BASE_MODEL)
                    cls._base_model = model
        return cls._base_model, cls._base_processor

    @classmethod
    def preload_all(cls):
        """Load every model once at startup instead of on the first user request."""
        cls.get_text_embed()
        cls.get_visual_embed()
        cls.get_base_model()
