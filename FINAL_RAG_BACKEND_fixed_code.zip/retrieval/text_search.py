from pathlib import Path
import config
from connection import ClientManager, ModelRegistry

def retrieve_text_context(user_query):
    client = ClientManager.get_qdrant()
    model = ModelRegistry.get_text_embed()

    query_vector = model.encode(user_query, prompt_name="query", truncate_dim=config.TEXT_EMBED_DIM).tolist()
    response = client.query_points(
        collection_name=config.TEXT_COLLECTION_NAME,
        query=query_vector,
        limit=config.TOP_K,
        with_payload=True
    )
    return response.points


def _read_normalised_text(path_to_file):
    # Same normalisation as ingestion, so start_char/end_char (character offsets) line up.
    with open(path_to_file, "r", encoding="utf-8", newline="") as source_f:
        return source_f.read().replace("\r\n", "\n").replace("\r", "\n")


def extract_text_chunks(matched_nodes):
    retrieved_chunks = []
    file_cache = {}
    for hit in matched_nodes:
        payload = hit.payload
        path_to_file = payload.get("file_path", "")

        # 1. Preferred: chunk text stored directly in the payload.
        resolved_chunk_text = payload.get("text")

        # 2. Fallback for points indexed before "text" was stored: slice the .txt by
        #    characters (never seek() by these offsets - seek() counts bytes).
        if resolved_chunk_text is None and path_to_file.lower().endswith(".txt"):
            try:
                if path_to_file not in file_cache:
                    file_cache[path_to_file] = _read_normalised_text(path_to_file)
                resolved_chunk_text = file_cache[path_to_file][payload["start_char"]:payload["end_char"]]
            except (OSError, UnicodeDecodeError, KeyError) as e:
                print(f"Could not resolve chunk from {path_to_file}: {e}")

        # 3. Anything else (e.g. OCR chunks whose file_path is a PDF and that carry no
        #    stored text) cannot be reconstructed - skip it instead of failing the request.
        if not resolved_chunk_text:
            print(f"Skipping hit without resolvable text (source: {payload.get('source')}, file: {path_to_file})")
            continue

        retrieved_chunks.append(resolved_chunk_text)
        print(f"\n[Score: {hit.score:.4f}] | Source: {Path(path_to_file).name}")
        print(f"Content Slice:\n{resolved_chunk_text}\n" + "-"*60)

    return retrieved_chunks
