import torch
from qdrant_client import models
import config
from connection import ClientManager, ModelRegistry, GPU_LOCK
from ingestion.visual_pipeline import _reset_rope_cache

def batch_embed_query(query_batch):
    model, processor = ModelRegistry.get_visual_embed()
    with GPU_LOCK, torch.no_grad():
        _reset_rope_cache(model)
        processed_queries = processor.process_queries(query_batch).to(model.device)
        query_embeddings_batch = model(**processed_queries)
    # drop padding tokens (zero vectors) so each query only carries its real tokens
    masks = processed_queries.attention_mask.bool().cpu()
    return [emb[mask].float().numpy().tolist() for emb, mask in zip(query_embeddings_batch.cpu(), masks)]

def reranking_search_batch(query_batch, prefetch_limit=200):
    client = ClientManager.get_qdrant()
    search_queries = [
        models.QueryRequest(
            query=query,
            prefetch=[
                models.Prefetch(query=query, limit=prefetch_limit, using="mean_pooling_columns"),
                models.Prefetch(query=query, limit=prefetch_limit, using="mean_pooling_rows"),
            ],
            limit=config.TOP_K,
            with_payload=True,
            with_vector=False,
            using="original"
        ) for query in query_batch
    ]
    return client.query_batch_points(collection_name=config.VISUAL_COLLECTION_NAME, requests=search_queries)