"""Environment + model check for the AKOS RAG backend.

    python check_env.py           # packages vs requirements.txt, imports, GPU, model configs
                                  # (downloads only the small config files from Hugging Face)
    python check_env.py --load    # additionally loads all 3 models and runs a tiny smoke test

Exit code 0 = everything passed, 1 = at least one check failed.
"""
import argparse
import importlib.metadata as md
import json
import sys
from pathlib import Path

from packaging.requirements import Requirement

import config

failures = []


def ok(msg):
    print(f"  [ OK ] {msg}")


def fail(msg):
    failures.append(msg)
    print(f"  [FAIL] {msg}")


def warn(msg):
    print(f"  [WARN] {msg}")


def check_packages():
    print("\n1. Installed packages vs requirements.txt")
    if sys.version_info < (3, 10):
        fail(f"Python {sys.version.split()[0]} is too old (3.12 recommended)")
    else:
        ok(f"Python {sys.version.split()[0]}")
    for line in (Path(__file__).parent / "requirements.txt").read_text().splitlines():
        line = line.split("#", 1)[0].strip()
        if not line:
            continue
        req = Requirement(line)
        try:
            version = md.version(req.name)
        except md.PackageNotFoundError:
            fail(f"{req.name} is not installed (need {req.specifier or 'any'})")
            continue
        if req.specifier and not req.specifier.contains(version, prereleases=True):
            fail(f"{req.name} {version} does not satisfy {req.specifier}")
        else:
            ok(f"{req.name} {version}")


def check_imports():
    print("\n2. Imports used by the backend")
    checks = [
        ("colpali_engine.models", ["ColQwen3_5", "ColQwen3_5Processor"]),
        ("transformers", ["Qwen3VLForConditionalGeneration", "AutoProcessor"]),
        ("sentence_transformers", ["SentenceTransformer"]),
        ("qdrant_client.models", ["Prefetch", "QueryRequest", "MultiVectorConfig", "Datatype"]),
        ("pypdfium2", ["PdfDocument"]),
        ("fastapi", ["FastAPI"]),
    ]
    for module, names in checks:
        try:
            mod = __import__(module, fromlist=names)
            missing = [n for n in names if not hasattr(mod, n)]
            if missing:
                fail(f"{module} has no {missing}")
            else:
                ok(f"{module}: {', '.join(names)}")
        except Exception as e:
            fail(f"import {module} failed: {e}")
    try:
        import main  # noqa: F401  (imports every backend module)
        ok("backend modules import (main.py)")
    except Exception as e:
        fail(f"importing main.py failed: {e}")


def check_gpu():
    print("\n3. GPU")
    import torch
    if not torch.cuda.is_available():
        warn(f"CUDA not available (torch {torch.__version__}, built for CUDA {torch.version.cuda}). "
             "Fine on a login node; on a GPU node this means torch does not match the driver.")
        return
    total = 0
    for i in range(torch.cuda.device_count()):
        p = torch.cuda.get_device_properties(i)
        total += p.total_memory
        ok(f"cuda:{i} {p.name} {p.total_memory / 2**30:.0f} GiB")
    # bf16 weights: Qwen3-Embedding-8B ~15 GB, colqwen3.5-4.5B ~9 GB, Qwen3-VL-8B ~17.5 GB
    if total / 2**30 < 48:
        warn(f"{total / 2**30:.0f} GiB GPU memory in total; the three models need ~42 GB of weights "
             "plus activations - plan for >= 48 GB (device_map='auto' spreads over all visible GPUs)")


def _hf_json(repo, filename):
    from huggingface_hub import hf_hub_download
    with open(hf_hub_download(repo, filename)) as f:
        return json.load(f)


def check_model_configs():
    print("\n4. Model ids and configs (Hugging Face)")
    try:
        cfg = _hf_json(config.TEXT_EMBED_MODEL, "config.json")
        hidden = cfg.get("hidden_size")
        if hidden and config.TEXT_EMBED_DIM <= hidden:
            ok(f"{config.TEXT_EMBED_MODEL}: hidden_size {hidden}, TEXT_EMBED_DIM {config.TEXT_EMBED_DIM} (MRL truncation)")
        else:
            fail(f"{config.TEXT_EMBED_MODEL}: hidden_size {hidden} < TEXT_EMBED_DIM {config.TEXT_EMBED_DIM}")
        st = _hf_json(config.TEXT_EMBED_MODEL, "config_sentence_transformers.json")
        if "query" in st.get("prompts", {}):
            ok(f"{config.TEXT_EMBED_MODEL}: has the 'query' prompt used by retrieval")
        else:
            fail(f"{config.TEXT_EMBED_MODEL}: no 'query' prompt in config_sentence_transformers.json")
    except Exception as e:
        fail(f"{config.TEXT_EMBED_MODEL}: could not fetch config ({e})")

    try:
        cfg = _hf_json(config.VISUAL_EMBED_MODEL, "config.json")
        dim = cfg.get("dim", 128)
        if dim == config.VISUAL_EMBED_DIM:
            ok(f"{config.VISUAL_EMBED_MODEL}: dim {dim} == VISUAL_EMBED_DIM")
        else:
            fail(f"{config.VISUAL_EMBED_MODEL}: dim {dim} != VISUAL_EMBED_DIM {config.VISUAL_EMBED_DIM}")
        if cfg.get("model_type") != "qwen3_5":
            fail(f"{config.VISUAL_EMBED_MODEL}: model_type {cfg.get('model_type')!r}, expected 'qwen3_5' for ColQwen3_5")
        else:
            ok(f"{config.VISUAL_EMBED_MODEL}: model_type qwen3_5 (ColQwen3_5)")
    except Exception as e:
        fail(f"{config.VISUAL_EMBED_MODEL}: could not fetch config ({e})")

    try:
        cfg = _hf_json(config.BASE_MODEL, "config.json")
        archs = cfg.get("architectures", [])
        if "Qwen3VLForConditionalGeneration" in archs:
            ok(f"{config.BASE_MODEL}: Qwen3VLForConditionalGeneration")
        else:
            fail(f"{config.BASE_MODEL}: architectures {archs}, expected Qwen3VLForConditionalGeneration")
    except Exception as e:
        fail(f"{config.BASE_MODEL}: could not fetch config ({e})")


def check_qdrant():
    print("\n5. Existing Qdrant collections")
    if not Path(config.QDRANT_PATH).exists():
        ok("no local storage yet (will be created on first start)")
        return
    try:
        from ingestion.common import check_vector_size
        from connection import ClientManager
        client = ClientManager.get_qdrant()
        for name, dim, vec in [(config.TEXT_COLLECTION_NAME, config.TEXT_EMBED_DIM, None),
                               (config.VISUAL_COLLECTION_NAME, config.VISUAL_EMBED_DIM, "original")]:
            if not client.collection_exists(name):
                ok(f"{name}: not created yet")
                continue
            try:
                check_vector_size(name, dim, vec)
                ok(f"{name}: vector size {dim}, {client.count(name).count} points")
            except RuntimeError as e:
                fail(str(e))
    except Exception as e:
        warn(f"could not open {config.QDRANT_PATH} ({e}) - is the API running? (local mode allows one process)")


def smoke_test():
    print("\n6. Loading models + smoke test")
    from PIL import Image, ImageDraw
    from connection import ModelRegistry
    from ingestion.visual_pipeline import embed_and_mean_pool_batch, extract_text_from_pil_image
    from ingestion.common import embed_documents
    from retrieval.visual_search import batch_embed_query
    try:
        model = ModelRegistry.get_text_embed()
        q = model.encode("Kdo podeljuje radijske frekvence?", prompt_name="query", truncate_dim=config.TEXT_EMBED_DIM)
        d = embed_documents(["Agencija dodeljuje radijske frekvence z odločbo."])[0]
        ok(f"text embedder: query {len(q)} dims, document {len(d)} dims")
    except Exception as e:
        fail(f"text embedder: {e}")
    page = Image.new("RGB", (1190, 1684), "white")
    ImageDraw.Draw(page).text((100, 100), "AKOS - porocilo o trgu 2025", fill="black")
    try:
        orig, rows, cols = embed_and_mean_pool_batch([page])
        q = batch_embed_query(["poročilo o trgu"])
        ok(f"ColQwen3.5: page {len(orig[0])}x{len(orig[0][0])}, rows {len(rows[0])}, cols {len(cols[0])}, "
           f"query {len(q[0])}x{len(q[0][0])}")
    except Exception as e:
        fail(f"ColQwen3.5: {e}")
    try:
        text = extract_text_from_pil_image(page)
        ok(f"Qwen3-VL OCR: {text[:60]!r}")
    except Exception as e:
        fail(f"Qwen3-VL: {e}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--load", action="store_true", help="load all models and run a smoke test (GPU node)")
    ap.add_argument("--offline", action="store_true", help="skip the Hugging Face config checks")
    args = ap.parse_args()
    check_packages()
    check_imports()
    check_gpu()
    if not args.offline:
        check_model_configs()
    check_qdrant()
    if args.load:
        smoke_test()
    print("\nRESULT:", "all checks passed" if not failures else f"{len(failures)} check(s) failed")
    sys.exit(1 if failures else 0)
