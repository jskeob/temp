import requests
from io import BytesIO
import pypdfium2 as pdfium
from PIL import Image
from pathlib import Path
from connection import ModelRegistry

_opened_pdf_cache = {}

def get_image_from_cache(payload):
    local_file_path=payload.get("local_path")
    url=payload.get("source")
    page_number=payload.get("page_number", 1)

    # 1. Fast Path: Use local cached file system
    if local_file_path and Path(local_file_path).exists():
        try:
            if local_file_path.lower().endswith('.pdf'):
                if local_file_path not in _opened_pdf_cache:
                    _opened_pdf_cache[local_file_path] = pdfium.PdfDocument(local_file_path)
                pdf = _opened_pdf_cache[local_file_path]
                return pdf[page_number-1].render(scale=2).to_pil().convert("RGB")
            else:
                return Image.open(local_file_path).convert("RGB")
        except Exception as e:
            print(f"Cache read error for {local_file_path}: {e}. Falling back to URL lookup.")

    print(f"Cache miss/error. Attempting live fallback download for: {url}")
    try:
        response=requests.get(url, timeout=10)
        response.raise_for_status()
        img_bytes=BytesIO(response.content)
        
        if url.lower().endswith('.pdf'):
            pdf=pdfium.PdfDocument(img_bytes)
            return pdf[page_number-1].render(scale=2).to_pil().convert("RGB")
        else:
            return Image.open(img_bytes).convert("RGB")
            
    except Exception as fallback_err:
        print(f"Critical Error: Could not resolve asset via cache or web: {fallback_err}")
        # Return standard clean canvas so Qwen3-VL doesn't break execution flow
        return Image.new('RGB', (1024, 1024), color='white')

def clear_request_cache():
    """Call this at the end of main.py's chat route to free up memory."""
    global _opened_pdf_cache
    for pdf in _opened_pdf_cache.values():
        pdf.close()
    _opened_pdf_cache.clear()

def answer_question(retrieved_text_batch,retrieved_visual_batch, question):
    model, processor = ModelRegistry.get_base_model()
    results = retrieved_visual_batch[0].points
    content = []
    
    for hit in results:
        img = get_image_from_cache(hit.payload)
        content.append({"type": "image", "image": img})
    for chunk in retrieved_text_batch:
        content.append({"type":"text","text":chunk})

    prompt_text = (
        f"Si strokovni asistent za slovensko zakonodajo in komunikacije za AKOS (Agencija za komunikacijska omrežja in storitve Republike Slovenije). "
        f"Na podlagi priloženih slikovnih in textovnih dokumentov odgovori na vprašanje: {question}. "
        f"Odgovori izključno v slovenščini. Če iz podatkov ni možno odgovoriti na vprašanje odgovori: Nimam dovolj podatkov, da bi odgovoril na vaše vprašanje."
    )
    content.append({"type": "text", "text": prompt_text})

    messages = [{"role": "user", "content": content}]
    inputs = processor.apply_chat_template(messages, tokenize=True, add_generation_prompt=True, return_dict=True, return_tensors="pt")
    inputs = inputs.to(model.device)

    generated_ids = model.generate(**inputs, max_new_tokens=1024)
    generated_ids_trimmed = [out_ids[len(in_ids):] for in_ids, out_ids in zip(inputs.input_ids, generated_ids)]
    output_text = processor.batch_decode(generated_ids_trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False)
    
    return output_text[0]