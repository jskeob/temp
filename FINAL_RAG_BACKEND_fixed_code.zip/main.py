import os
import threading
import uvicorn
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
from contextlib import asynccontextmanager

from ingestion import init_qdrant_text, process_txt_files, init_qdrant_vis, process_urls
from retrieval import retrieve_text_context, extract_text_chunks, batch_embed_query, reranking_search_batch
from service import answer_question, clear_request_cache
from connection import ModelRegistry, GPU_LOCK

NO_ANSWER = "Nimam dovolj podatkov, da bi odgovoril na vaše vprašanje."

# Only one ingestion run at a time; its state is visible via GET /api/ingest/status.
_ingestion_lock = threading.Lock()
_ingestion_state = {"running": False, "last_result": None}

# --- Modern Lifespan Event Handler ---
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initializes Qdrant collections on API startup."""
    print("Initializing Qdrant collections...")
    init_qdrant_text()
    init_qdrant_vis()
    if os.getenv("PRELOAD_MODELS", "1") == "1":
        print("Preloading models (set PRELOAD_MODELS=0 to load lazily)...")
        ModelRegistry.preload_all()
    yield
    print("Shutting down API...")

# Initialize FastAPI App
app = FastAPI(
    title="AKOS Multimodal RAG API",
    description="Backend API supporting text and visual document intelligence for AKOS.",
    version="1.0.0",
    lifespan=lifespan
)

# Enable CORS for WebUI integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Pydantic Schemas for API Requests/Responses ---
class ChatRequest(BaseModel):
    question: str

class ChatResponse(BaseModel):
    answer: str
    sources: List[str]  # Keeping this list required

# --- Background Ingestion Task ---
def background_ingestion():
    print("--- Starting Background Ingestion ---")
    try:
        process_txt_files()
        process_urls()
        _ingestion_state["last_result"] = "completed"
        print("--- Ingestion Completed Successfully ---")
    except Exception as e:
        _ingestion_state["last_result"] = f"failed: {e}"
        print(f"Ingestion failed: {e}")
    finally:
        _ingestion_state["running"] = False
        _ingestion_lock.release()

# --- API Endpoints ---

@app.post("/api/ingest", status_code=202) # Fixed: status_index -> status_code
def trigger_ingestion(background_tasks: BackgroundTasks):
    """
    Triggers the ingestion pipeline asynchronously so it doesn't block the WebUI.
    """
    if not _ingestion_lock.acquire(blocking=False):
        raise HTTPException(status_code=409, detail="Ingestion is already running.")
    _ingestion_state["running"] = True
    background_tasks.add_task(background_ingestion)
    return {"status": "Ingestion started in the background."}

@app.get("/api/ingest/status")
def ingestion_status():
    return _ingestion_state

# Plain `def` (not `async def`): FastAPI runs it in a worker thread, so blocking GPU
# work no longer freezes the event loop (health checks, other requests).
@app.post("/api/chat", response_model=ChatResponse)
def chat_endpoint(payload: ChatRequest):
    """
    Handles queries from the WebUI, extracts text/visual context, and returns the VL answer.
    """
    question = payload.question.strip()
    if not question:
        raise HTTPException(status_code=400, detail="Question cannot be empty.")

    try:
        with GPU_LOCK:
            try:
                # 1. Retrieve text slices
                text_hits = retrieve_text_context(question)
                text_chunks = extract_text_chunks(text_hits)
                # 2. Retrieve visual components (ColQwen multi-vectors)
                visual_query = batch_embed_query([question])
                visual_results = reranking_search_batch(visual_query)
                # 3. Generate orchestrator response via Qwen3-VL
                final_answer = answer_question(text_chunks, visual_results, question)
            finally:
                # always release opened PDFs, also when something above fails
                clear_request_cache()
        info_sources=[]
        # tolerant check: the model may add whitespace or drop the final period
        if not final_answer.strip().startswith(NO_ANSWER.rstrip(".")):
            for el in visual_results[0].points:
                info_sources.append(el.payload.get("source"))
            for el in text_hits:
                info_sources.append(el.payload.get("source"))

        info_sources = list(dict.fromkeys(s for s in info_sources if s))  # dedupe, keep order
        
        return ChatResponse(
            answer=final_answer,
            sources=info_sources
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred during processing: {str(e)}")

@app.get("/api/health")
def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    # Ensure this script file is named exactly `main.py` for this to map correctly
    # reload=True restarts the server on code changes - development only (RAG_DEV=1)
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=os.getenv("RAG_DEV") == "1")