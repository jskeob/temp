import io
import hashlib
import os
import requests
import torch
import pypdfium2 as pdfium
from PIL import Image
from qdrant_client import models
import config
from connection import ClientManager, ModelRegistry, GPU_LOCK
from .common import build_text_points, check_vector_size, existing_ids, point_id, upsert_in_order


def init_qdrant_vis():
    client = ClientManager.get_qdrant()
    if not client.collection_exists(config.VISUAL_COLLECTION_NAME):
        dim = config.VISUAL_EMBED_DIM
        client.create_collection(
            collection_name=config.VISUAL_COLLECTION_NAME,
            vectors_config={
                "original": models.VectorParams(
                    size=dim, distance=models.Distance.COSINE,on_disk=True,datatype=models.Datatype.FLOAT16,
                    multivector_config=models.MultiVectorConfig(comparator=models.MultiVectorComparator.MAX_SIM),
                    hnsw_config=models.HnswConfigDiff(m=0)
                ),
                "mean_pooling_columns": models.VectorParams(
                    size=dim, distance=models.Distance.COSINE,on_disk=True,datatype=models.Datatype.FLOAT16,
                    multivector_config=models.MultiVectorConfig(comparator=models.MultiVectorComparator.MAX_SIM)
                ),
                "mean_pooling_rows": models.VectorParams(
                    size=dim, distance=models.Distance.COSINE,on_disk=True,datatype=models.Datatype.FLOAT16,
                    multivector_config=models.MultiVectorConfig(comparator=models.MultiVectorComparator.MAX_SIM)
                )
            },
            quantization_config=models.BinaryQuantization(
                binary=models.BinaryQuantizationConfig(always_ram=True)
            )
        )
        client.create_payload_index(
            collection_name=config.VISUAL_COLLECTION_NAME,
            field_name="image_hash",
            field_schema=models.PayloadSchemaType.KEYWORD,
        )
    check_vector_size(config.VISUAL_COLLECTION_NAME, config.VISUAL_EMBED_DIM, vector_name="original")


def hash_image(image):
    img_byte_arr = io.BytesIO()
    image.save(img_byte_arr, format='PNG')
    return hashlib.sha256(img_byte_arr.getvalue()).hexdigest()


# ---------------------------------------------------------------- download / cache

def _sniff_extension(head: bytes):
    """Decide the type from the file's magic bytes, not from the URL."""
    if head.startswith(b"%PDF"):
        return ".pdf"
    if head.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if head.startswith(b"\xff\xd8\xff"):
        return ".jpg"
    return None


def download_and_cache_media(url):
    """Returns the local cached path (…/<sha256(url)>.pdf|.png|.jpg) or None."""
    config.CACHE_DIR.mkdir(parents=True, exist_ok=True)
    url_hash = hashlib.sha256(url.encode('utf-8')).hexdigest()

    for ext in (".pdf", ".png", ".jpg"):
        cached = config.CACHE_DIR / f"{url_hash}{ext}"
        if cached.exists():
            print(f"Cache hit! Accessing local file system for: {url}")
            return cached

    print(f"📥 Downloading and caching target: {url}")
    tmp_path = config.CACHE_DIR / f"{url_hash}.part"
    try:
        with requests.get(url, timeout=30, stream=True) as response:
            response.raise_for_status()
            with open(tmp_path, "wb") as f:
                for block in response.iter_content(chunk_size=1 << 20):
                    f.write(block)
        with open(tmp_path, "rb") as f:
            ext = _sniff_extension(f.read(16))
        if ext is None:
            print(f"Skipping {url}: not a PDF/PNG/JPEG (content-type: {response.headers.get('content-type')})")
            tmp_path.unlink(missing_ok=True)
            return None
        local_path = config.CACHE_DIR / f"{url_hash}{ext}"
        os.replace(tmp_path, local_path)          # atomic: no half-written cache files
        return local_path
    except Exception as e:
        print(f"Failed to cache resource from {url}: {e}")
        tmp_path.unlink(missing_ok=True)
        return None


# ---------------------------------------------------------------- visual embeddings

def _reset_rope_cache(model):
    # Qwen3.5 caches rope_deltas between forward passes; the model card asks to clear it so
    # a page embedding never leaks positions into the next forward pass.
    for m in (model, getattr(model, "base_model", None)):
        if m is not None and hasattr(m, "rope_deltas"):
            m.rope_deltas = None


def embed_and_mean_pool_batch(image_batch):
    model, processor = ModelRegistry.get_visual_embed()
    with GPU_LOCK, torch.no_grad():
        _reset_rope_cache(model)
        processed_images = processor.process_images(image_batch).to(model.device)
        image_embeddings = model(**processed_images)

    image_embeddings_batch = []
    pooled_by_rows_batch = []
    pooled_by_columns_batch = []

    for image_embedding, tokenized_image, attention_mask, image in zip(
            image_embeddings, processed_images.input_ids, processed_images.attention_mask, image_batch):
        # drop left padding (only present when batch_size > 1)
        image_embedding = image_embedding[attention_mask.bool()]
        tokenized_image = tokenized_image[attention_mask.bool()]

        x_patches, y_patches = processor.get_n_patches(image.size, spatial_merge_size=model.spatial_merge_size)
        image_tokens_mask = (tokenized_image == processor.image_token_id)
        n_image_tokens = int(image_tokens_mask.sum())
        if n_image_tokens != x_patches * y_patches:
            raise ValueError(f"Expected {x_patches}x{y_patches} image tokens, got {n_image_tokens}")

        # Image tokens are laid out row by row: (rows = y, columns = x).
        grid = image_embedding[image_tokens_mask].view(y_patches, x_patches, model.dim)
        pooled_by_rows = grid.mean(dim=1)      # one vector per row    -> (y, dim)
        pooled_by_columns = grid.mean(dim=0)   # one vector per column -> (x, dim)

        image_token_idxs = torch.nonzero(image_tokens_mask.int(), as_tuple=False)
        prefix_tokens = image_embedding[:image_token_idxs[0].cpu().item()]
        postfix_tokens = image_embedding[image_token_idxs[-1].cpu().item() + 1:]

        image_embeddings_batch.append(image_embedding.cpu().float().numpy().tolist())
        pooled_by_rows_batch.append(torch.cat((prefix_tokens, pooled_by_rows, postfix_tokens), dim=0).cpu().float().numpy().tolist())
        pooled_by_columns_batch.append(torch.cat((prefix_tokens, pooled_by_columns, postfix_tokens), dim=0).cpu().float().numpy().tolist())

    return image_embeddings_batch, pooled_by_rows_batch, pooled_by_columns_batch


# ---------------------------------------------------------------- OCR

def extract_text_from_pil_image(pil_image) -> str:
    #samo zamenjas z ocr knjiznico ce je treba
    model, processor = ModelRegistry.get_base_model()

    prompt_text = (
        "Deluješ kot strokovnjak za digitalizacijo in napredno optično prepoznavo znakov (OCR). "
        "Natančno in dobesedno prepiši celotno besedilo s te slike. "
        "Ohrani strukturo postavitve, naslove in tabele z uporabo čiste Markdown oblike. "
        "Besedilo mora ostati v slovenščini (vključno s šumniki č, š, ž). "
        "Ne dodajaj svojih komentarjev, ne popravljaj slovnice in ne dodajaj klepetalnih mašil. "
        "Izpiši SAMO prepisano besedilo."
    )
    content = [
        {"type": "image", "image": pil_image},
        {"type": "text", "text": prompt_text}
    ]
    messages = [{"role": "user", "content": content}]
    with GPU_LOCK, torch.no_grad():
        inputs = processor.apply_chat_template(messages,tokenize=True, add_generation_prompt=True,return_dict=True,return_tensors="pt")
        inputs = inputs.to(model.device)
        generated_ids = model.generate(**inputs, max_new_tokens=4096,do_sample=False)
    generated_ids_trimmed = [out_ids[len(in_ids):] for in_ids, out_ids in zip(inputs.input_ids, generated_ids)]
    output_text = processor.batch_decode(generated_ids_trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False)
    return output_text[0]


# ---------------------------------------------------------------- per-page indexing

def _page_id(doc_hash, page_number):
    return point_id("page", doc_hash, page_number)


def index_page(image, page_number, doc_hash, local_path, url):
    """OCR text first, page image last: the visual point is the "page done" marker, so a
    page whose OCR or embedding failed is retried on the next run."""
    image_hash = hash_image(image)

    print(f"Performing Qwen-VL OCR on page {page_number}...")
    ocr_text = extract_text_from_pil_image(image).replace("\r\n", "\n").replace("\r", "\n")
    text_points = build_text_points(ocr_text, ("ocr", doc_hash, page_number), {
        "text_hash": image_hash,
        "file_path": str(local_path),
        "source": str(url),
        "page_number": page_number,
        "origin": "ocr",
    })
    if text_points:
        upsert_in_order(config.TEXT_COLLECTION_NAME, text_points)

    orig, rows, cols = embed_and_mean_pool_batch([image])
    ClientManager.get_qdrant().upsert(
        collection_name=config.VISUAL_COLLECTION_NAME,
        points=[models.PointStruct(
            id=_page_id(doc_hash, page_number),
            vector={"original": orig[0], "mean_pooling_rows": rows[0], "mean_pooling_columns": cols[0]},
            payload={"source": url, "local_path": str(local_path), "page_number": page_number,
                     "image_hash": image_hash, "doc_hash": doc_hash},
        )],
        wait=True,
    )
    return len(text_points)


def process_document(url, local_path):
    doc_hash = hashlib.sha256(local_path.read_bytes()).hexdigest()
    is_pdf = local_path.suffix == ".pdf"
    pdf = pdfium.PdfDocument(str(local_path)) if is_pdf else None
    try:
        n_pages = len(pdf) if is_pdf else 1
        # O(1) per page: look up the deterministic page IDs - no rendering, no scans.
        wanted = {_page_id(doc_hash, p): p for p in range(1, n_pages + 1)}
        done = existing_ids(config.VISUAL_COLLECTION_NAME, wanted)
        todo = [p for pid, p in wanted.items() if pid not in done]
        if not todo:
            print(f"Already indexed ({n_pages} page(s)). Skipping {url}")
            return
        print(f"Indexing {len(todo)}/{n_pages} page(s) of {url}")

        for page_number in todo:
            try:
                if is_pdf:
                    page = pdf[page_number - 1]
                    image = page.render(scale=config.PDF_RENDER_SCALE).to_pil().convert("RGB")
                    page.close()
                else:
                    with Image.open(local_path) as im:
                        image = im.convert("RGB")
                n_chunks = index_page(image, page_number, doc_hash, local_path, url)
                print(f"  page {page_number}: indexed ({n_chunks} OCR text chunks)")
            except Exception as e:
                print(f"  page {page_number}: FAILED ({e}) - will be retried on the next run")
    finally:
        if pdf is not None:
            pdf.close()


def _read_urls():
    urls = []
    for file in sorted(config.URL_DIR.iterdir()):
        if not file.is_file() or file.suffix != '.txt':
            continue
        with open(file, "r", encoding="utf-8") as f:
            for line in f:                       # iterate lines, not characters
                url = line.strip()
                if url and not url.startswith("#") and url not in urls:
                    urls.append(url)
    return urls


def process_urls():
    if not config.URL_DIR.exists():
        return
    for url in _read_urls():
        print(f"\nProcessing target: {url}")
        try:
            local_file_path = download_and_cache_media(url)
            if not local_file_path:
                continue        # reason already printed by download_and_cache_media
            process_document(url, local_file_path)
        except Exception as e:
            print(f"Failed to process {url}: {e}")
