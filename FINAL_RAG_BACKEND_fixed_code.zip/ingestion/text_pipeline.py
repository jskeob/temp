import hashlib
import re
from qdrant_client import models
import config
from connection import ClientManager
from .common import build_text_points, check_vector_size, existing_ids, last_chunk_id, upsert_in_order

HEADER_PATTERN = re.compile(r"TITLE:\s*(.*?)\s*\nURL:\s*(.*?)\s*\nMETHOD:\s*(.*?)\s*\nCONTENT:\s*\n-+\s*\n(.*)", re.DOTALL)


def init_qdrant_text():
    client = ClientManager.get_qdrant()
    if not client.collection_exists(config.TEXT_COLLECTION_NAME):
        client.create_collection(
            collection_name=config.TEXT_COLLECTION_NAME,
            vectors_config=models.VectorParams(size=config.TEXT_EMBED_DIM, distance=models.Distance.COSINE,datatype=models.Datatype.FLOAT16,on_disk=True)
        )
        # Only used for filtering on a Qdrant server; duplicate checks use point IDs.
        client.create_payload_index(
            collection_name=config.TEXT_COLLECTION_NAME,
            field_name="text_hash",
            field_schema=models.PayloadSchemaType.KEYWORD,
        )
        print(f"Collection {config.TEXT_COLLECTION_NAME} created.")
    check_vector_size(config.TEXT_COLLECTION_NAME, config.TEXT_EMBED_DIM)


def _text_id_parts(file_hash):
    return ("txt", file_hash)


def is_inside_text_qdrant(file_hash, text):
    """O(1): looks up the ID of the file's last chunk (written last) instead of scanning."""
    marker = last_chunk_id(text, _text_id_parts(file_hash))
    return marker is None or marker in existing_ids(config.TEXT_COLLECTION_NAME, [marker])


def process_txt_files():
    if not config.CLEANED_HTML_DIR.exists():
        return

    skipped, indexed, already = [], 0, 0
    for file in sorted(config.CLEANED_HTML_DIR.iterdir()):
        if not file.is_file() or file.suffix != '.txt':
            continue

        # One bad file must not stop the whole run (e.g. cleaning_log.txt is not UTF-8,
        # failed_cleanings.txt / successful_cleanings.txt have no TITLE/URL header).
        try:
            raw = file.read_bytes()
            text = raw.decode("utf-8")
        except (OSError, UnicodeDecodeError) as e:
            print(f"Skipping {file.name}: cannot read as UTF-8 ({e})")
            skipped.append(file.name)
            continue

        text = text.replace("\r\n", "\n").replace("\r", "\n")
        match = HEADER_PATTERN.search(text)
        if not match:
            print(f"Skipping {file.name}: does not match the TITLE/URL/METHOD/CONTENT format")
            skipped.append(file.name)
            continue
        url = match.group(2).strip()

        file_hash = hashlib.sha256(raw).hexdigest()
        if is_inside_text_qdrant(file_hash, text):
            already += 1
            continue
        print("Processing Text File:", file.name)

        points = build_text_points(text, _text_id_parts(file_hash), {
            "text_hash": file_hash,
            "file_path": str(file.resolve()),
            "source": str(url),
        })
        if points:
            upsert_in_order(config.TEXT_COLLECTION_NAME, points)
            indexed += 1
            print(f"Successfully indexed {len(points)} chunks for {file.name}")

    print(f"Text ingestion: {indexed} file(s) indexed, {already} already indexed/duplicate, "
          f"{len(skipped)} skipped {skipped if skipped else ''}")
