from .text_pipeline import init_qdrant_text, process_txt_files
from .visual_pipeline import init_qdrant_vis, process_urls

# This defines exactly what gets imported when using 'from ingestion import *'
__all__ = [
    "init_qdrant_text",
    "process_txt_files",
    "init_qdrant_vis",
    "process_urls",
]