"""Helpers shared by the text and visual ingestion pipelines.

Duplicate detection works on deterministic point IDs instead of payload-filter scans:
every point's ID is a UUIDv5 of (kind, content hash, position). "Is this already
indexed?" is then a lookup by ID (client.retrieve), which is O(1) per ID both in local
mode and on a Qdrant server - no linear scan over the collection. Re-ingesting the same
content also overwrites the same points instead of creating duplicates.
"""
import uuid
from qdrant_client import models
import config
from connection import ClientManager, ModelRegistry, GPU_LOCK

_ID_NAMESPACE = uuid.UUID("6f1c3d2e-8a4b-4f5e-9c7d-2b1a0e9f8d7c")


def point_id(*parts) -> str:
    return str(uuid.uuid5(_ID_NAMESPACE, ":".join(str(p) for p in parts)))


def existing_ids(collection_name, ids):
    """Return the subset of `ids` that already exist in the collection (lookup by ID)."""
    client = ClientManager.get_qdrant()
    found = set()
    ids = list(ids)
    for i in range(0, len(ids), config.UPSERT_BATCH_SIZE):
        records = client.retrieve(
            collection_name=collection_name,
            ids=ids[i:i + config.UPSERT_BATCH_SIZE],
            with_payload=False,
            with_vectors=False,
        )
        found.update(str(r.id) for r in records)
    return found


def check_vector_size(collection_name, expected, vector_name=None):
    """Fail early with a clear message if an existing collection was built with another dim."""
    client = ClientManager.get_qdrant()
    vectors = client.get_collection(collection_name).config.params.vectors
    params = vectors[vector_name] if vector_name else vectors
    if params.size != expected:
        raise RuntimeError(
            f"Collection '{collection_name}' has vector size {params.size}, but the model/config "
            f"expects {expected}. Delete the collection (or {config.QDRANT_PATH}) and re-ingest."
        )


def split_into_chunks(text):
    """Character windows of CHUNK_SIZE with OVERLAP. Returns (core_text, ctx_start, ctx_end)."""
    chunks = []
    for start_idx in range(0, len(text), config.CHUNK_SIZE - config.OVERLAP):
        end_idx = min(start_idx + config.CHUNK_SIZE, len(text))
        core = text[start_idx:end_idx]
        if not core.strip():
            continue
        chunks.append((core,
                       max(start_idx - config.CONTEXT_PAD, 0),
                       min(end_idx + config.CONTEXT_PAD, len(text))))
    return chunks


def embed_documents(texts):
    """Embed document chunks. Qwen3-Embedding: documents get NO instruction (model card);
    only queries use the "query" prompt. The GPU lock is taken per batch so chat requests
    can interleave with a long ingestion run."""
    model = ModelRegistry.get_text_embed()
    vectors = []
    for i in range(0, len(texts), config.TEXT_EMBED_BATCH_SIZE):
        with GPU_LOCK:
            batch = model.encode(texts[i:i + config.TEXT_EMBED_BATCH_SIZE],
                                 truncate_dim=config.TEXT_EMBED_DIM,
                                 batch_size=config.TEXT_EMBED_BATCH_SIZE)
        vectors.extend(v.tolist() for v in batch)
    return vectors


def build_text_points(text, id_parts, base_payload):
    """Chunk `text`, embed it and return PointStructs with deterministic IDs.
    The last point in the list is the "document done" marker (it is upserted last)."""
    chunks = split_into_chunks(text)
    if not chunks:
        return []
    vectors = embed_documents([core for core, _, _ in chunks])
    points = []
    for idx, ((core, ctx_start, ctx_end), vec) in enumerate(zip(chunks, vectors)):
        payload = dict(base_payload)
        payload.update({
            "chunk_index": idx,
            "start_char": ctx_start,   # character offsets (not bytes) into the normalised text
            "end_char": ctx_end,
            "text": text[ctx_start:ctx_end],
        })
        points.append(models.PointStruct(id=point_id(*id_parts, idx), vector=vec, payload=payload))
    return points


def last_chunk_id(text, id_parts):
    """ID of the last chunk `build_text_points` would create (None if there are no chunks)."""
    n = len(split_into_chunks(text))
    return point_id(*id_parts, n - 1) if n else None


def upsert_in_order(collection_name, points):
    """Upsert in batches, in order, waiting for each - so if the marker (last point) exists,
    every earlier point of that document exists too."""
    client = ClientManager.get_qdrant()
    for i in range(0, len(points), config.UPSERT_BATCH_SIZE):
        client.upsert(collection_name=collection_name,
                      points=points[i:i + config.UPSERT_BATCH_SIZE], wait=True)
